// DUMMY PRODUCTS (PRODUCT ID : DATA)
var products = {
  123: {
    name : "MARGHERITA",
    desc : "Fresh tomatoes, fresh mozzarella, fresh basil",
    img : "Margherita.jpeg",
    price : 12.50
  },
  124: {
    name : "FORMAGGIO",
    desc : "Four cheeses (mozzarella, parmesan, pecorino, jarlsberg)",
    img : "formaggios.jpeg",
    price : 15.50
  },
  125: {
    name : "Pineapple'o'clock",
    desc : "Fresh tomatoes, mozzarella, fresh pineapple, bacon, fresh basil",
    img : "pineapple.jpeg",
    price : 16.50
  },
  126: {
    name : "Meat Town",
    desc : "Fresh tomatoes, mozzarella, hot pepporoni, hot sausage, beef, chicken",
    img : "meat.jpeg",
    price : 20.00
  },
  127: {
    name : "Bruschetta",
    desc : "Bread with pesto, tomatoes, onion, garlic",
    img : "brushetta.png",
    price : 8.50
  },
  128: {
    name : "Garlic bread",
    desc : "Grilled ciabatta, garlic butter, onions",
    img : "garlic_bread.jpeg",
    price : 15.50
  },
  129: {
    name : "Tomozzarella",
    desc : "Tomatoes and mozzarella",
    img : "tomozzarella.jpg",
    price : 10.50
  },
};